# knight (pixel)

| Action | Frames passed | Attempts | Frames to check by hand | Time | Spend | Meta API calls: new / cached |
| --- | --- | --- | --- | --- | --- | --- |
| dance | 40/48 | 85 | 2, 11, 14, 16, 17, 19, 32, 33 | 15.3 min | $2.98 | 255 / 5 |

Total spend: $2.98 (cached calls are free).

A frame passes when its silhouette matches the pose guide (SAM 3.1), the Muse Spark critic scores pose and identity at least 7, its colours stay on the sheet palette and its legs moved like the actor's. A frame to check did not pass every check after the redraws; the best attempt is used.
