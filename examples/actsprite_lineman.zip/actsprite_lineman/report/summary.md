# lineman (lineart)

| Action | Frames passed | Attempts | Frames to check by hand | Time | Spend | Meta API calls: new / cached |
| --- | --- | --- | --- | --- | --- | --- |
| run | 16/20 | 37 | 3, 6, 13, 14 | 3.2 min | $0.21 | 19 / 93 |
| attack | 6/10 | 24 | 1, 6, 7, 9 | 3.7 min | $0.53 | 51 / 21 |

Total spend: $0.74 (cached calls are free).

A frame passes when its silhouette matches the pose guide (SAM 3.1), the Muse Spark critic scores pose and identity at least 7, its colours stay on the sheet palette and its legs moved like the actor's. A frame to check did not pass every check after the redraws; the best attempt is used.
