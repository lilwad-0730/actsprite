# lineman (lineart)

| Action | Frames passed | Attempts | Frames to check by hand | Time | Spend | Meta API calls: new / cached |
| --- | --- | --- | --- | --- | --- | --- |
| attack | 5/8 | 19 | 5, 6, 7 | 0.8 min | $0.00 | 0 / 57 |

Total spend: $0.00 (cached calls are free).

Rebuilt from the API cache with no new Meta API calls: attack. Their time and spend are those of the rebuild, not of a first run (see the project README for measured runs).

A frame passes when its silhouette matches the pose guide (SAM 3.1), the Muse Spark critic scores pose and identity at least 7, its colours stay on the sheet palette and its legs moved like the actor's. A frame to check did not pass every check after the redraws; the best attempt is used.
