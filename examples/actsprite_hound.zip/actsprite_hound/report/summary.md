# hound (pixel)

| Action | Frames passed | Attempts | Frames to check by hand | Time | Spend | Meta API calls: new / cached |
| --- | --- | --- | --- | --- | --- | --- |
| walk | 4/10 | 27 | 1, 2, 3, 4, 5, 8 | 5.7 min | $1.01 | 81 / 1 |

Total spend: $1.01 (cached calls are free).

A frame passes when its silhouette matches the pose guide (SAM 3.1), the Muse Spark critic scores pose and identity at least 7, its colours stay on the sheet palette and its legs moved like the actor's. A frame to check did not pass every check after the redraws; the best attempt is used.
